﻿using System.Data.SQLite;
using System.Windows;

namespace DBShell
{
    /// <summary>
    /// Логика взаимодействия для wdStudentInfo.xaml
    /// </summary>
    public partial class wdStudentInfo : Window
    {
        Student student;
        string db = "students.db";
        public wdStudentInfo()
        {
            InitializeComponent();
            student = null;
        }

        public wdStudentInfo(Student info)
        {
            InitializeComponent();
            student = info;
            txtStudentFIO.Text = student.StudentFIO;
            txtBirthDate.Text = student.BirthDate;
        }
    
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SQLiteConnection connection;
            connection = new SQLiteConnection("Data Source=" + db + ";Version=3;");
            connection.Open();
            string StudentFIO = txtStudentFIO.Text;
            string BirthDate = txtBirthDate.Text;
            if (student == null)
            {
                string sql = @"INSERT INTO Students ( StudentFIO,  BirthDate) VALUES(@StudentFIO,  @BirthDate)";
                SQLiteCommand command = new SQLiteCommand(sql, connection);
                command.Parameters.AddWithValue("@StudentFIO", StudentFIO);
                command.Parameters.AddWithValue("@BirthDate", txtBirthDate.Text);
                command.ExecuteNonQuery();
            }
            else
            {
                string sql = @"UPDATE Students SET 
                                     StudentFIO = @StudentFIO,  
                                     BirthDate = @BirthDate 
                               WHERE StudentID = @StudentID";
                SQLiteCommand command = new SQLiteCommand(sql, connection);
                command.Parameters.AddWithValue("@StudentFIO", StudentFIO);
                command.Parameters.AddWithValue("@BirthDate", BirthDate);
                command.Parameters.AddWithValue("@StudentID", student.ID);
                command.ExecuteNonQuery();
            }
            connection.Close();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
