﻿using System.Data.SQLite;
using System.Windows;

namespace DBShell
{
    public partial class wdGrades : Window
    {
        public Student student;
        public string db = "students.db";

        public wdGrades(Student info)
        {
            InitializeComponent();
            student = info;
            txtMathemGrades.Text = student.MathemGrades;
            txtPhysicsGrades.Text = student.PhysicsGrades;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SQLiteConnection connection;
            connection = new SQLiteConnection("Data Source=" + db + ";Version=3;");
            connection.Open();

            string MathemGrades = txtMathemGrades.Text;
            string PhysicsGrades = txtPhysicsGrades.Text;
            if (string.IsNullOrEmpty(student.MathemGrades))
            {
                string sql = @"INSERT INTO StudentGrades (StudentID, PhysicsGrades, MathemGrades) VALUES(@StudentID, @PhysicsGrades, @MathemGrades)";
                SQLiteCommand command = new SQLiteCommand(sql, connection);
                command.Parameters.AddWithValue("@StudentID", student.ID);
                command.Parameters.AddWithValue("@PhysicsGrades", PhysicsGrades);
                command.Parameters.AddWithValue("@MathemGrades", MathemGrades);
                command.ExecuteNonQuery();
            }
            else
            {
                string sql = @"UPDATE StudentGrades SET PhysicsGrades = @PhysicsGrades,  MathemGrades = @MathemGrades WHERE StudentID = @StudentID";
                SQLiteCommand command = new SQLiteCommand(sql, connection);
                command.Parameters.AddWithValue("@PhysicsGrades", PhysicsGrades);
                command.Parameters.AddWithValue("@MathemGrades", MathemGrades);
                command.Parameters.AddWithValue("@StudentID", student.ID);
                command.ExecuteNonQuery();
            }
            connection.Close();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
