﻿namespace DBShell
{
    public class Student
    {
        public int ID { get; set; }
        public string StudentFIO { get; set; }
        public string PhysicsGrades { get; set; }
        public string MathemGrades { get; set; }
        public string BirthDate { get; set; }

    }
}
