﻿using System.Data.SQLite;
using System.Windows;

namespace DBShell
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string db = "students.db";

        public MainWindow()
        {
            InitializeComponent();
            GetList();
        }

        private void GetList()
        {
            SQLiteConnection connection;
            connection = new SQLiteConnection("Data Source=" + db + ";Version=3;");
            connection.Open();

            string sql = @"SELECT s.StudentID, s. StudentFIO, s.BirthDate, m.PhysicsGrades, m.MathemGrades
                            FROM Students s
                            Left JOIN StudentGrades m on S.studentId = m.StudentId
                            ORDER BY StudentFIO";
            SQLiteCommand command = new SQLiteCommand(sql, connection);
            SQLiteDataReader reader = command.ExecuteReader();

            dgvStudents.Items.Clear();
            while (reader.Read())
            {
                Student student = new Student
                {
                    ID = int.Parse(reader["StudentID"].ToString()),
                    StudentFIO = reader["StudentFIO"].ToString(),
                    PhysicsGrades = reader["PhysicsGrades"].ToString(),
                    MathemGrades = reader["MathemGrades"].ToString(),
                    BirthDate = reader["BirthDate"].ToString()
                };
                dgvStudents.Items.Add(student);

            }
            reader.Close();
            connection.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            wdStudentInfo wdStudentInfo = new wdStudentInfo();
            wdStudentInfo.ShowDialog();
            GetList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Student student = (Student)dgvStudents.SelectedItem;
            if (student != null)
            {
                wdStudentInfo wdStudentInfo = new wdStudentInfo(student);
                wdStudentInfo.ShowDialog();
                GetList();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Student student = (Student)dgvStudents.SelectedItem;
            if (student != null)
            {
                wdGrades wdGrades = new wdGrades(student);
                wdGrades.ShowDialog();
                GetList();
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Student student = (Student)dgvStudents.SelectedItem;

            if (student != null)
            {
                SQLiteConnection connection;
                connection = new SQLiteConnection("Data Source=" + db + ";Version=3;");
                connection.Open();

                string sql = @"DELETE FROM Students 
                               WHERE StudentID = @StudentID";

                SQLiteCommand command = new SQLiteCommand(sql, connection);
                command.Parameters.AddWithValue("@StudentID", student.ID);

                command.ExecuteNonQuery();
                connection.Close();
                GetList();
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Student studInfo = (Student)dgvStudents.SelectedItem;
            if (studInfo != null)
            {
                wdGrades wdGrades = new wdGrades(studInfo);
                wdGrades.ShowDialog();
                GetList();
            }
        }
    }
}
